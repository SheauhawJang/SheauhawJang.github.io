﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week10_A
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Manager.Points = new List<Point>();
        }
        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            Form form = (Form)sender;
            Graphics g = form.CreateGraphics();
            if (Manager.Points.Count > 0)
            {
                Pen blackp = new Pen(Color.Black);
                g.DrawLine(blackp, e.Location, Manager.Points.Last());
            }
            SolidBrush yellowb = new SolidBrush(Color.Yellow);
            g.FillEllipse(yellowb, Manager.GetRect(e.Location));
            Manager.Points.Add(e.Location);
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            SolidBrush yellowb = new SolidBrush(Color.Yellow);
            Pen blackp = new Pen(Color.Black);
            for (int i = 0; i < Manager.Points.Count; ++i)
            {
                if (i > 0)
                    g.DrawLine(blackp, Manager.Points[i], Manager.Points[i - 1]);
                g.FillEllipse(yellowb, Manager.GetRect(Manager.Points[i]));
            }
        }
    }
    public static class Manager
    {
        public static List<Point> Points { get; set; }
        public static Rectangle GetRect(Point p)
        {
            const int sizer = 10;
            return new Rectangle(p.X - sizer, p.Y - sizer, 2 * sizer, 2 * sizer);
        }
    }
}
