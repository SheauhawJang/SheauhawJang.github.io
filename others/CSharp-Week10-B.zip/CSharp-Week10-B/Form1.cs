﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week10_B
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void 画线ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manager.LastSelected = Manager.DrawType.Line;
            Cursor = Cursors.Hand;
        }

        private void 画圆ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manager.LastSelected = Manager.DrawType.Circle;
            Cursor = Cursors.Hand;
        }

        private void 画矩形ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manager.LastSelected = Manager.DrawType.Rectangle;
            Cursor = Cursors.Hand;
        }

        private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manager.LastSelected = Manager.DrawType.None;
            Cursor = Cursors.Default;
            Manager.Histories.Clear();
            Refresh();
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (Manager.LastSelected != Manager.DrawType.None)
            {
                Graphics g = CreateGraphics();
                Pen p = new Pen(Manager.SelectedColor);
                SolidBrush brush = new SolidBrush(Manager.SelectedColor);
                Manager.DrawHistory history = new Manager.DrawHistory
                {
                    dt = Manager.LastSelected,
                    pt = e.Location,
                    color = Manager.SelectedColor
                };
                switch (Manager.LastSelected)
                {
                    case Manager.DrawType.Line:
                        if (Manager.LineSavedCheck)
                        {
                            g.DrawLine(p, e.Location, Manager.LineSave);
                            history.ed = Manager.LineSave;
                        }
                        else
                            Manager.LineSave = e.Location;
                        break;
                    case Manager.DrawType.Circle:
                        g.FillEllipse(brush, e.X - 15, e.Y - 15, 30, 30);
                        break;
                    case Manager.DrawType.Rectangle:
                        g.FillRectangle(brush, e.X, e.Y, 10, 20);
                        break;
                }
                if (Manager.LastSelected == Manager.DrawType.Line)
                    Manager.LineSavedCheck = !Manager.LineSavedCheck;
                else
                    Manager.LineSavedCheck = false;
                if (!Manager.LineSavedCheck)
                {
                    Manager.LastSelected = Manager.DrawType.None;
                    Cursor = Cursors.Default;
                }
                Manager.Histories.Add(history);
            }
        }

        private void 颜色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            Manager.SelectedColor = colorDialog1.Color;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            foreach (Manager.DrawHistory his in Manager.Histories)
            {
                Pen pen = new Pen(his.color);
                SolidBrush brush = new SolidBrush(his.color);
                switch (his.dt)
                {
                    case Manager.DrawType.Line:
                        g.DrawLine(pen, his.pt, his.ed);
                        break;
                    case Manager.DrawType.Circle:
                        g.FillEllipse(brush, his.pt.X - 15, his.pt.Y - 15, 30, 30);
                        break;
                    case Manager.DrawType.Rectangle:
                        g.FillRectangle(brush, his.pt.X, his.pt.Y, 10, 20);
                        break;
                }
            }
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Written by Sheauhaw Jang.\nAll Rights Recieved.", 
                "关于", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    public static class Manager
    {
        public enum DrawType { None, Line, Circle, Rectangle };
        public struct DrawHistory
        {
            public DrawType dt;
            public Point pt, ed;
            public Color color;
        }
        public static DrawType LastSelected { get; set; } = DrawType.None;
        public static List<DrawHistory> Histories { get; set; } = new List<DrawHistory>();
        public static Point LineSave { get; set; }
        public static bool LineSavedCheck { get; set; } = false;
        public static Color SelectedColor { get; set; } = Color.Black;
    }
}
