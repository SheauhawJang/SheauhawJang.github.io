﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week10_C
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            GraphicsPath path = new GraphicsPath();
            Font font = new Font("Arial", 16, FontStyle.Regular);
            path.AddString("1", font.FontFamily, (int)font.Style, font.Size, new Point(10, 10), StringFormat.GenericTypographic);
            SolidBrush brush = new SolidBrush(Color.White);
            g.FillPath(brush, path);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen linePen = new Pen(Color.Black);
            linePen.Width = 5;
            // Heng
            int xbegin = Manager.netR, xend = Manager.netTotal - Manager.netR;
            int thisy = Manager.netR;
            for (int i = 0; i < Manager.netSize; ++i)
            {
                Point lp = new Point(xbegin, thisy);
                Point rp = new Point(xend, thisy);
                g.DrawLine(linePen, lp, rp);
                thisy += Manager.netD;
            }
            // Zong
            int ybegin = Manager.netR, yend = Manager.netTotal - Manager.netR;
            int thisx = Manager.netR;
            for (int i = 0; i < Manager.netSize; ++i)
            {
                Point lp = new Point(thisx, ybegin);
                Point rp = new Point(thisx, yend);
                g.DrawLine(linePen, lp, rp);
                thisx += Manager.netD;
            }
            // Points
            for (int i = 0; i < Manager.History.Count; ++i)
            {
                Manager.DrawPiece((Panel)sender, Manager.History[i], i);
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            Manager.Location loc = new Manager.Location(e.X / Manager.netD, e.Y / Manager.netD);
            if (Math.Max(loc.X, loc.Y) >= Manager.netSize) return;
            if (Manager.History.Contains(loc)) return;
            Manager.DrawPiece((Panel)sender, loc, Manager.History.Count);
            Manager.History.Add(loc);
        }
    }
    public static class Manager
    {
        public const int netR = 25;
        public const int netD = 2 * netR;
        public const int netSize = 15;
        public const int netTotal = netD * netSize;
        public const int pieceR = 20;
        public const int pieceD = 2 * pieceR;
        public const int lineWidth = 5;
        public struct Location
        {
            public int X { get; private set; }
            public int Y { get; private set; }
            public Location(int x, int y) { X = x; Y = y; }
        }
        public static List<Location> History { get; set; } = new List<Location>();
        public static void DrawPiece(Control sender, Location loc, int i)
        {
            Control panel = sender;
            Graphics g = panel.CreateGraphics();
            Color color = (i & 1) == 0 ? Color.Black : Color.White;
            Color reColor = (i & 1) == 1 ? Color.Black : Color.White;
            SolidBrush pieceBrush = new SolidBrush(color);
            Point centerPoint = new Point
            {
                X = loc.X * netD + netR,
                Y = loc.Y * netD + netR
            };
            Point piecePoint = centerPoint;
            piecePoint.Offset(-pieceR, -pieceR);
            Size size = new Size(pieceD, pieceD);
            Rectangle rect = new Rectangle(piecePoint, size);
            g.FillEllipse(pieceBrush, rect);
            Font font = new Font("Arial", 24);
            StringFormat format = new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };
            GraphicsPath path = new GraphicsPath();
            path.AddString(Convert.ToString(i + 1), font.FontFamily,
                (int)font.Style, font.Size, rect, format);
            SolidBrush fontBrush = new SolidBrush(reColor);
            g.FillPath(fontBrush, path);
        }
    }
}
