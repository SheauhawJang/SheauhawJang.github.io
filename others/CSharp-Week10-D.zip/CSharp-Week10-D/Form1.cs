﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week10_D
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_Layout(object sender, LayoutEventArgs e)
        {
            Panel panel = (Panel)sender;
            panel.Size = Manager.PanelSize;
        }

        private void Retimer_Tick(object sender, EventArgs e)
        {
            if (Manager.LeftPressed)
                Manager.PlateX -= Manager.StepMovement;
            if (Manager.RightPressed)
                Manager.PlateX += Manager.StepMovement;
            if (Manager.PlateX < 0)
                Manager.PlateX = 0;
            if (Manager.PlateX + Manager.PlateSize.Width >= Manager.PanelSize.Width)
                Manager.PlateX = Manager.PanelSize.Width - Manager.PlateSize.Width;
                for (int i = 0; i < Manager.Balls.Count; ++i)
            {
                Point x = Manager.Balls[i].Center;
                x.Offset(0, Manager.BallFallingMovement);
                Manager.Balls[i] = new Ball(x);
            }
            panel1.Refresh();
            for (int i = 0; i < Manager.Balls.Count; ++i)
            {
                Ball b = Manager.Balls[i];
                if (b.Y + Ball.radius >= Manager.PlateY)
                {
                    bool check = b.X - Manager.PlateX >= 0 &&
                        b.X - Manager.PlateX <= Manager.PlateSize.Width;
                    Manager.Balls.RemoveAt(i);
                    if (check)
                        ++Manager.Score;
                    else
                    {
                        Retimer.Stop();
                        MessageBox.Show(
                            string.Format("Game Over!\nYou got {0} scores!", Manager.Score),
                            "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Close();
                    }
                }
            }
            int maxball = (int)Math.Log(Manager.Score + 1) + 1;
            if (Manager.Balls.Count < maxball)
                if (Manager.Balls.Count == 0 || Manager.CoolDown == 0)
                {
                    if (Manager.Balls.Count == 0 || Manager.Random.Next(100) < Manager.Probability)
                    {
                        Manager.CoolDown = Manager.CoolDownUpdate;
                        int newx = Manager.Random.Next(Ball.radius, Manager.PanelSize.Width - Ball.radius);
                        int newy = Ball.radius;
                        Manager.Balls.Add(new Ball(newx, newy));
                    }
                }
                else
                    --Manager.CoolDown;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    Manager.LeftPressed = true;
                    break;
                case Keys.Right:
                    Manager.RightPressed = true;
                    break;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    Manager.LeftPressed = false;
                    break;
                case Keys.Right:
                    Manager.RightPressed = false;
                    break;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            SolidBrush ballBrush = new SolidBrush(Manager.BallColor);
            foreach (Ball b in Manager.Balls)
                g.FillEllipse(ballBrush, b.Rectangle);
            SolidBrush plateBrush = new SolidBrush(Manager.PlateColor);
            g.FillRectangle(plateBrush, Manager.Plate);
        }
    }
    public struct Ball
    {
        public Point Center { get; set; }
        public int X { get => Center.X; }
        public int Y { get => Center.Y; }
        public const int radius = 10;
        public readonly static Size size = new Size(2 * radius, 2 * radius);
        public Rectangle Rectangle
        {
            get 
            {
                Point side = Center;
                side.Offset(-radius, -radius);
                return new Rectangle(side, size);
            }
        }
        public Ball(int x, int y) { Center = new Point(x, y); }
        public Ball(Point pt) { Center = pt; }
    }
    public static class Manager
    {
        public static List<Ball> Balls { get; set; } = new List<Ball>();
        public static Size PanelSize { get => new Size(300, 600); }
        public static Size PlateSize { get => new Size(40, 10); }
        public static int PlateX { get; set; }
        public static int PlateY { get => PanelSize.Height - PlateSize.Height - ButtonDis; }
        public static Point PlatePoint { get => new Point(PlateX, PlateY); }
        public static Rectangle Plate { get => new Rectangle(PlatePoint, PlateSize); }
        public static int ButtonDis { get => 5; }
        public static int StepMovement { get => 5; }
        public static int BallFallingMovement { get => 10; }
        public static int Score { get; set; } = 0;
        public static Random Random { get; set; } = new Random();
        public static Color BallColor { get => Color.White; }
        public static Color PlateColor { get => Color.Yellow; }
        public static int Probability { get => 1; }
        public static int CoolDown { get; set; } = 0;
        public static int CoolDownUpdate { get => Random.Next(10, 30); }
        public static bool LeftPressed { get; set; } = false;
        public static bool RightPressed { get; set; } = false;
    }
}
