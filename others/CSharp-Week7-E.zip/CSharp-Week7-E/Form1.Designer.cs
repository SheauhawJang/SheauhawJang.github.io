﻿namespace CSharp_Week7_E
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BaseText = new System.Windows.Forms.TextBox();
            this.BaseLabel = new System.Windows.Forms.Label();
            this.RateText = new System.Windows.Forms.TextBox();
            this.YearsUpDown = new System.Windows.Forms.NumericUpDown();
            this.RateLabel = new System.Windows.Forms.Label();
            this.YearsLabel = new System.Windows.Forms.Label();
            this.AnsLabel = new System.Windows.Forms.Label();
            this.NameButton = new System.Windows.Forms.Label();
            this.ConfirmButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.CopyrightButton = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.InterestTypeLabel = new System.Windows.Forms.Label();
            this.SimpleInterestCheck = new System.Windows.Forms.CheckBox();
            this.ComplexInterestCheck = new System.Windows.Forms.CheckBox();
            this.AnsText = new System.Windows.Forms.TextBox();
            this.PrecentCheck = new System.Windows.Forms.CheckBox();
            this.ValueRangeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.YearsUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // BaseText
            // 
            this.BaseText.Location = new System.Drawing.Point(47, 12);
            this.BaseText.Name = "BaseText";
            this.BaseText.Size = new System.Drawing.Size(190, 21);
            this.BaseText.TabIndex = 1;
            // 
            // BaseLabel
            // 
            this.BaseLabel.AutoSize = true;
            this.BaseLabel.Location = new System.Drawing.Point(12, 16);
            this.BaseLabel.Name = "BaseLabel";
            this.BaseLabel.Size = new System.Drawing.Size(29, 12);
            this.BaseLabel.TabIndex = 2;
            this.BaseLabel.Text = "本金";
            // 
            // RateText
            // 
            this.RateText.Location = new System.Drawing.Point(47, 39);
            this.RateText.Name = "RateText";
            this.RateText.Size = new System.Drawing.Size(154, 21);
            this.RateText.TabIndex = 1;
            // 
            // YearsUpDown
            // 
            this.YearsUpDown.Location = new System.Drawing.Point(71, 66);
            this.YearsUpDown.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.YearsUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.YearsUpDown.Name = "YearsUpDown";
            this.YearsUpDown.Size = new System.Drawing.Size(102, 21);
            this.YearsUpDown.TabIndex = 3;
            this.YearsUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // RateLabel
            // 
            this.RateLabel.AutoSize = true;
            this.RateLabel.Location = new System.Drawing.Point(12, 43);
            this.RateLabel.Name = "RateLabel";
            this.RateLabel.Size = new System.Drawing.Size(29, 12);
            this.RateLabel.TabIndex = 2;
            this.RateLabel.Text = "利率";
            // 
            // YearsLabel
            // 
            this.YearsLabel.AutoSize = true;
            this.YearsLabel.Location = new System.Drawing.Point(12, 70);
            this.YearsLabel.Name = "YearsLabel";
            this.YearsLabel.Size = new System.Drawing.Size(53, 12);
            this.YearsLabel.TabIndex = 2;
            this.YearsLabel.Text = "储蓄年数";
            // 
            // AnsLabel
            // 
            this.AnsLabel.AutoSize = true;
            this.AnsLabel.Location = new System.Drawing.Point(12, 124);
            this.AnsLabel.Name = "AnsLabel";
            this.AnsLabel.Size = new System.Drawing.Size(53, 12);
            this.AnsLabel.TabIndex = 2;
            this.AnsLabel.Text = "本息总和";
            // 
            // NameButton
            // 
            this.NameButton.AutoSize = true;
            this.NameButton.Location = new System.Drawing.Point(12, 173);
            this.NameButton.Name = "NameButton";
            this.NameButton.Size = new System.Drawing.Size(149, 12);
            this.NameButton.TabIndex = 4;
            this.NameButton.Text = "Written by Sheauhaw Jang";
            // 
            // ConfirmButton
            // 
            this.ConfirmButton.Location = new System.Drawing.Point(14, 147);
            this.ConfirmButton.Name = "ConfirmButton";
            this.ConfirmButton.Size = new System.Drawing.Size(75, 23);
            this.ConfirmButton.TabIndex = 5;
            this.ConfirmButton.Text = "确定";
            this.ConfirmButton.UseVisualStyleBackColor = true;
            this.ConfirmButton.Click += new System.EventHandler(this.ConfirmButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(162, 147);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(75, 23);
            this.ClearButton.TabIndex = 6;
            this.ClearButton.Text = "归零";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // CopyrightButton
            // 
            this.CopyrightButton.AutoSize = true;
            this.CopyrightButton.Location = new System.Drawing.Point(12, 203);
            this.CopyrightButton.Name = "CopyrightButton";
            this.CopyrightButton.Size = new System.Drawing.Size(125, 12);
            this.CopyrightButton.TabIndex = 7;
            this.CopyrightButton.Text = "All rights reserved.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 188);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "2020-11-10 19:37:18";
            // 
            // InterestTypeLabel
            // 
            this.InterestTypeLabel.AutoSize = true;
            this.InterestTypeLabel.Location = new System.Drawing.Point(12, 96);
            this.InterestTypeLabel.Name = "InterestTypeLabel";
            this.InterestTypeLabel.Size = new System.Drawing.Size(53, 12);
            this.InterestTypeLabel.TabIndex = 2;
            this.InterestTypeLabel.Text = "储蓄类型";
            // 
            // SimpleInterestCheck
            // 
            this.SimpleInterestCheck.AutoSize = true;
            this.SimpleInterestCheck.Location = new System.Drawing.Point(71, 95);
            this.SimpleInterestCheck.Name = "SimpleInterestCheck";
            this.SimpleInterestCheck.Size = new System.Drawing.Size(48, 16);
            this.SimpleInterestCheck.TabIndex = 8;
            this.SimpleInterestCheck.Text = "单利";
            this.SimpleInterestCheck.UseVisualStyleBackColor = true;
            this.SimpleInterestCheck.CheckedChanged += new System.EventHandler(this.SimpleInterestCheck_CheckedChanged);
            // 
            // ComplexInterestCheck
            // 
            this.ComplexInterestCheck.AutoSize = true;
            this.ComplexInterestCheck.Location = new System.Drawing.Point(125, 95);
            this.ComplexInterestCheck.Name = "ComplexInterestCheck";
            this.ComplexInterestCheck.Size = new System.Drawing.Size(48, 16);
            this.ComplexInterestCheck.TabIndex = 9;
            this.ComplexInterestCheck.Text = "复利";
            this.ComplexInterestCheck.UseVisualStyleBackColor = true;
            this.ComplexInterestCheck.CheckedChanged += new System.EventHandler(this.ComplexInterestCheck_CheckedChanged);
            // 
            // AnsText
            // 
            this.AnsText.Location = new System.Drawing.Point(71, 120);
            this.AnsText.Name = "AnsText";
            this.AnsText.ReadOnly = true;
            this.AnsText.Size = new System.Drawing.Size(166, 21);
            this.AnsText.TabIndex = 1;
            // 
            // PrecentCheck
            // 
            this.PrecentCheck.AutoSize = true;
            this.PrecentCheck.Location = new System.Drawing.Point(207, 41);
            this.PrecentCheck.Name = "PrecentCheck";
            this.PrecentCheck.Size = new System.Drawing.Size(30, 16);
            this.PrecentCheck.TabIndex = 10;
            this.PrecentCheck.Text = "%";
            this.PrecentCheck.UseVisualStyleBackColor = true;
            // 
            // ValueRangeLabel
            // 
            this.ValueRangeLabel.AutoSize = true;
            this.ValueRangeLabel.Location = new System.Drawing.Point(178, 71);
            this.ValueRangeLabel.Name = "ValueRangeLabel";
            this.ValueRangeLabel.Size = new System.Drawing.Size(59, 12);
            this.ValueRangeLabel.TabIndex = 11;
            this.ValueRangeLabel.Text = "范围: 1-5";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(249, 223);
            this.Controls.Add(this.ValueRangeLabel);
            this.Controls.Add(this.PrecentCheck);
            this.Controls.Add(this.ComplexInterestCheck);
            this.Controls.Add(this.SimpleInterestCheck);
            this.Controls.Add(this.CopyrightButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.ConfirmButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NameButton);
            this.Controls.Add(this.YearsUpDown);
            this.Controls.Add(this.InterestTypeLabel);
            this.Controls.Add(this.AnsLabel);
            this.Controls.Add(this.YearsLabel);
            this.Controls.Add(this.RateLabel);
            this.Controls.Add(this.BaseLabel);
            this.Controls.Add(this.AnsText);
            this.Controls.Add(this.RateText);
            this.Controls.Add(this.BaseText);
            this.Name = "Form1";
            this.Text = "利率计算程序";
            ((System.ComponentModel.ISupportInitialize)(this.YearsUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox BaseText;
        private System.Windows.Forms.Label BaseLabel;
        private System.Windows.Forms.TextBox RateText;
        private System.Windows.Forms.NumericUpDown YearsUpDown;
        private System.Windows.Forms.Label RateLabel;
        private System.Windows.Forms.Label YearsLabel;
        private System.Windows.Forms.Label AnsLabel;
        private System.Windows.Forms.Label NameButton;
        private System.Windows.Forms.Button ConfirmButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Label CopyrightButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label InterestTypeLabel;
        private System.Windows.Forms.CheckBox SimpleInterestCheck;
        private System.Windows.Forms.CheckBox ComplexInterestCheck;
        private System.Windows.Forms.TextBox AnsText;
        private System.Windows.Forms.CheckBox PrecentCheck;
        private System.Windows.Forms.Label ValueRangeLabel;
    }
}

