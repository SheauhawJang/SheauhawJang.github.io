﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week7_E
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SimpleInterestCheck.Checked = true;
        }

        private void ConfirmButton_Click(object sender, EventArgs e)
        {
            try
            {
                double basval, rate;
                int years;
                try { basval = Convert.ToDouble(BaseText.Text); }
                catch { throw new ApplicationException("Base Value Error!"); }
                try { rate = Convert.ToDouble(RateText.Text); }
                catch { throw new ApplicationException("Rate Value Error!"); }
                if (PrecentCheck.Checked)
                    rate /= 100;
                years = Convert.ToInt32(YearsUpDown.Value);
                double ans = basval;
                if (SimpleInterestCheck.Checked)
                    ans += years * basval * rate;
                else if (ComplexInterestCheck.Checked)
                    ans *= Calculator.FastPow(1 + rate, years);
                else
                    throw new ApplicationException("No Interest Type!");
                AnsText.Text = string.Format("{0:F2}", Math.Round(ans, 2));
            }
            catch (ApplicationException err)
            {
                AnsText.Text = err.Message;
            }
            catch
            {
                AnsText.Text = "Unknown Error!";
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            BaseText.Text = "";
            RateText.Text = "";
            YearsUpDown.Value = 1;
            AnsText.Text = "";
        }

        private void SimpleInterestCheck_CheckedChanged(object sender, EventArgs e)
        {
            ComplexInterestCheck.Checked = !SimpleInterestCheck.Checked;
        }

        private void ComplexInterestCheck_CheckedChanged(object sender, EventArgs e)
        {
            SimpleInterestCheck.Checked = !ComplexInterestCheck.Checked;
        }
    }
    static class Calculator
    {
        public static double FastPow(double a, int p)
        {
            double ans = 1;
            while (p != 0)
            {
                if ((p & 1) != 0)
                    ans *= a;
                a *= a;
                p >>= 1;
            }
            return ans;
        }
    }
}
