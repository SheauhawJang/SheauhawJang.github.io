﻿namespace CSharp_Week8_A
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Problem1Label = new System.Windows.Forms.Label();
            this.Answer1Text = new System.Windows.Forms.TextBox();
            this.Problem2Label = new System.Windows.Forms.Label();
            this.Answer2Text = new System.Windows.Forms.TextBox();
            this.Problem3Label = new System.Windows.Forms.Label();
            this.Answer3Text = new System.Windows.Forms.TextBox();
            this.Problem4Label = new System.Windows.Forms.Label();
            this.Answer4Text = new System.Windows.Forms.TextBox();
            this.Problem5Label = new System.Windows.Forms.Label();
            this.Answer5Text = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ScoreText = new System.Windows.Forms.TextBox();
            this.ConfirmButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Problem1Label
            // 
            this.Problem1Label.AutoSize = true;
            this.Problem1Label.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Problem1Label.Location = new System.Drawing.Point(10, 10);
            this.Problem1Label.Name = "Problem1Label";
            this.Problem1Label.Size = new System.Drawing.Size(63, 19);
            this.Problem1Label.TabIndex = 0;
            this.Problem1Label.Text = "aa+aa=";
            // 
            // Answer1Text
            // 
            this.Answer1Text.Location = new System.Drawing.Point(80, 10);
            this.Answer1Text.Name = "Answer1Text";
            this.Answer1Text.Size = new System.Drawing.Size(179, 21);
            this.Answer1Text.TabIndex = 1;
            // 
            // Problem2Label
            // 
            this.Problem2Label.AutoSize = true;
            this.Problem2Label.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Problem2Label.Location = new System.Drawing.Point(10, 37);
            this.Problem2Label.Name = "Problem2Label";
            this.Problem2Label.Size = new System.Drawing.Size(63, 19);
            this.Problem2Label.TabIndex = 0;
            this.Problem2Label.Text = "aa+aa=";
            // 
            // Answer2Text
            // 
            this.Answer2Text.Location = new System.Drawing.Point(80, 37);
            this.Answer2Text.Name = "Answer2Text";
            this.Answer2Text.Size = new System.Drawing.Size(179, 21);
            this.Answer2Text.TabIndex = 1;
            // 
            // Problem3Label
            // 
            this.Problem3Label.AutoSize = true;
            this.Problem3Label.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Problem3Label.Location = new System.Drawing.Point(10, 64);
            this.Problem3Label.Name = "Problem3Label";
            this.Problem3Label.Size = new System.Drawing.Size(63, 19);
            this.Problem3Label.TabIndex = 0;
            this.Problem3Label.Text = "aa+aa=";
            // 
            // Answer3Text
            // 
            this.Answer3Text.Location = new System.Drawing.Point(80, 64);
            this.Answer3Text.Name = "Answer3Text";
            this.Answer3Text.Size = new System.Drawing.Size(179, 21);
            this.Answer3Text.TabIndex = 1;
            // 
            // Problem4Label
            // 
            this.Problem4Label.AutoSize = true;
            this.Problem4Label.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Problem4Label.Location = new System.Drawing.Point(10, 91);
            this.Problem4Label.Name = "Problem4Label";
            this.Problem4Label.Size = new System.Drawing.Size(63, 19);
            this.Problem4Label.TabIndex = 0;
            this.Problem4Label.Text = "aa+aa=";
            // 
            // Answer4Text
            // 
            this.Answer4Text.Location = new System.Drawing.Point(80, 91);
            this.Answer4Text.Name = "Answer4Text";
            this.Answer4Text.Size = new System.Drawing.Size(179, 21);
            this.Answer4Text.TabIndex = 1;
            // 
            // Problem5Label
            // 
            this.Problem5Label.AutoSize = true;
            this.Problem5Label.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Problem5Label.Location = new System.Drawing.Point(10, 118);
            this.Problem5Label.Name = "Problem5Label";
            this.Problem5Label.Size = new System.Drawing.Size(63, 19);
            this.Problem5Label.TabIndex = 0;
            this.Problem5Label.Text = "aa+aa=";
            // 
            // Answer5Text
            // 
            this.Answer5Text.Location = new System.Drawing.Point(80, 118);
            this.Answer5Text.Name = "Answer5Text";
            this.Answer5Text.Size = new System.Drawing.Size(179, 21);
            this.Answer5Text.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(10, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "得分";
            // 
            // ScoreText
            // 
            this.ScoreText.Location = new System.Drawing.Point(80, 145);
            this.ScoreText.Name = "ScoreText";
            this.ScoreText.ReadOnly = true;
            this.ScoreText.Size = new System.Drawing.Size(179, 21);
            this.ScoreText.TabIndex = 1;
            // 
            // ConfirmButton
            // 
            this.ConfirmButton.Location = new System.Drawing.Point(14, 172);
            this.ConfirmButton.Name = "ConfirmButton";
            this.ConfirmButton.Size = new System.Drawing.Size(75, 23);
            this.ConfirmButton.TabIndex = 2;
            this.ConfirmButton.Text = "提交";
            this.ConfirmButton.UseVisualStyleBackColor = true;
            this.ConfirmButton.Click += new System.EventHandler(this.ConfirmButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(184, 172);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(75, 23);
            this.ClearButton.TabIndex = 2;
            this.ClearButton.Text = "清空";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(271, 205);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.ConfirmButton);
            this.Controls.Add(this.ScoreText);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Answer5Text);
            this.Controls.Add(this.Problem5Label);
            this.Controls.Add(this.Answer4Text);
            this.Controls.Add(this.Problem4Label);
            this.Controls.Add(this.Answer3Text);
            this.Controls.Add(this.Problem3Label);
            this.Controls.Add(this.Answer2Text);
            this.Controls.Add(this.Problem2Label);
            this.Controls.Add(this.Answer1Text);
            this.Controls.Add(this.Problem1Label);
            this.Name = "Form1";
            this.Text = "加减乘法训练软件";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Problem1Label;
        private System.Windows.Forms.TextBox Answer1Text;
        private System.Windows.Forms.Label Problem2Label;
        private System.Windows.Forms.TextBox Answer2Text;
        private System.Windows.Forms.Label Problem3Label;
        private System.Windows.Forms.TextBox Answer3Text;
        private System.Windows.Forms.Label Problem4Label;
        private System.Windows.Forms.TextBox Answer4Text;
        private System.Windows.Forms.Label Problem5Label;
        private System.Windows.Forms.TextBox Answer5Text;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ScoreText;
        private System.Windows.Forms.Button ConfirmButton;
        private System.Windows.Forms.Button ClearButton;
    }
}

