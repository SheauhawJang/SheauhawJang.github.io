﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week8_A
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Manager.problems = new Label[5];
            Manager.problems[0] = Problem1Label;
            Manager.problems[1] = Problem2Label;
            Manager.problems[2] = Problem3Label;
            Manager.problems[3] = Problem4Label;
            Manager.problems[4] = Problem5Label;
            Manager.answers = new TextBox[5];
            Manager.answers[0] = Answer1Text;
            Manager.answers[1] = Answer2Text;
            Manager.answers[2] = Answer3Text;
            Manager.answers[3] = Answer4Text;
            Manager.answers[4] = Answer5Text;
            Manager.standard = new int[5];
            Random tool = new Random();
            for (int i = 0; i < 5; ++i)
            {
                int a = tool.Next(1, 100);
                int b = tool.Next(1, 100);
                int sym = tool.Next(0, 3);
                Manager.problems[i].Text = Convert.ToString(a);
                switch (sym)
                {
                    case 1:
                        Manager.problems[i].Text += "+";
                        Manager.standard[i] = a + b;
                        break;
                    case 2:
                        Manager.problems[i].Text += "-";
                        Manager.standard[i] = a - b;
                        break;
                    case 0:
                        Manager.problems[i].Text += "*";
                        Manager.standard[i] = a * b;
                        break;
                }
                Manager.problems[i].Text += Convert.ToString(b);
                Manager.problems[i].Text += "=";
            }
        }

        private void ConfirmButton_Click(object sender, EventArgs e)
        {
            int pt = 0;
            for (int i = 0; i < 5; ++i)
            {
                try
                {
                    if (Convert.ToInt32(Manager.answers[i].Text) == Manager.standard[i])
                    {
                        pt += 20;
                        Manager.answers[i].BackColor = Color.Green;
                    }
                    else
                        throw new WrongAnswerException("Wrong Answer!");
                }
                catch 
                {
                    Manager.answers[i].BackColor = Color.Red;
                }
            }
            ScoreText.Text = Convert.ToString(pt);
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; ++i)
            {
                Manager.answers[i].Text = "";
                Manager.answers[i].BackColor = SystemColors.Window;
            }
            ScoreText.Text = "";
        }
    }

    static class Manager
    {
        public static Label[] problems;
        public static TextBox[] answers;
        public static int[] standard;
    }
    public class WrongAnswerException : ApplicationException
    {
        public WrongAnswerException(string message) : base(message) { }
    }
}
