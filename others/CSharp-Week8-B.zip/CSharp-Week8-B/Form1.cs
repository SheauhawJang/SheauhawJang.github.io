﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week8_B
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Manager.Last == Keys.S)
            {
                for (int i = 0; i < 3; ++i)
                    if (Manager.Index == i)
                        Manager.lights[i].BackColor = Manager.defaultColor[i];
                    else
                        Manager.lights[i].BackColor = Color.Gray;
                if (Manager.Index == 2)
                    Manager.Index = 0;
                else
                    ++Manager.Index;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Manager.lights = new PictureBox[3];
            Manager.lights[0] = RedLightPicture;
            Manager.lights[1] = YellowLightPicture;
            Manager.lights[2] = GreenLightPicture;
            Manager.defaultColor = new Color[3] { Color.Red, Color.Yellow, Color.Green };
            timer1.Start(); 
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            Manager.RealLast = e.KeyCode;
            if (e.KeyCode == Keys.S)
                Manager.Last = Keys.S;
            if (e.KeyCode == Keys.E)
                Manager.Last = Keys.E;
            LastKeyText.Text = Convert.ToString(Manager.RealLast);
        }
    }
    public static class Manager
    {
        public static Keys Last { get; set; }
        public static Keys RealLast { get; set; }
        public static int Index { get; set; }
        public static PictureBox[] lights;
        public static Color[] defaultColor;
    }
}
