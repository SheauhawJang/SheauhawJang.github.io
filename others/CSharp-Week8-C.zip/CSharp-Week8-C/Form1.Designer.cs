﻿namespace CSharp_Week8_C
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.AddedList = new System.Windows.Forms.ListBox();
            this.AddedListLabel = new System.Windows.Forms.Label();
            this.AddListLabel = new System.Windows.Forms.Label();
            this.AddListText = new System.Windows.Forms.TextBox();
            this.AddListButton = new System.Windows.Forms.Button();
            this.SelectedListLabel = new System.Windows.Forms.Label();
            this.SelectedListList = new System.Windows.Forms.ListBox();
            this.DeleteSelectedListButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.AddedCombo = new System.Windows.Forms.ComboBox();
            this.AddComboLabel = new System.Windows.Forms.Label();
            this.AddComboText = new System.Windows.Forms.TextBox();
            this.AddComboButton = new System.Windows.Forms.Button();
            this.SelectedComboLabel = new System.Windows.Forms.Label();
            this.DeletedSelectedComboButton = new System.Windows.Forms.Button();
            this.SelectedComboList = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // AddedList
            // 
            this.AddedList.FormattingEnabled = true;
            this.AddedList.ItemHeight = 12;
            this.AddedList.Location = new System.Drawing.Point(20, 40);
            this.AddedList.Name = "AddedList";
            this.AddedList.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.AddedList.Size = new System.Drawing.Size(120, 112);
            this.AddedList.TabIndex = 0;
            this.AddedList.Click += new System.EventHandler(this.AddedList_Click);
            // 
            // AddedListLabel
            // 
            this.AddedListLabel.AutoSize = true;
            this.AddedListLabel.Location = new System.Drawing.Point(20, 20);
            this.AddedListLabel.Name = "AddedListLabel";
            this.AddedListLabel.Size = new System.Drawing.Size(107, 12);
            this.AddedListLabel.TabIndex = 1;
            this.AddedListLabel.Text = "已选课列表ListBox";
            // 
            // AddListLabel
            // 
            this.AddListLabel.AutoSize = true;
            this.AddListLabel.Location = new System.Drawing.Point(20, 180);
            this.AddListLabel.Name = "AddListLabel";
            this.AddListLabel.Size = new System.Drawing.Size(71, 12);
            this.AddListLabel.TabIndex = 1;
            this.AddListLabel.Text = "添加1门课程";
            // 
            // AddListText
            // 
            this.AddListText.Location = new System.Drawing.Point(20, 200);
            this.AddListText.Name = "AddListText";
            this.AddListText.Size = new System.Drawing.Size(120, 21);
            this.AddListText.TabIndex = 2;
            // 
            // AddListButton
            // 
            this.AddListButton.Location = new System.Drawing.Point(20, 225);
            this.AddListButton.Name = "AddListButton";
            this.AddListButton.Size = new System.Drawing.Size(120, 23);
            this.AddListButton.TabIndex = 3;
            this.AddListButton.Text = "添加";
            this.AddListButton.UseVisualStyleBackColor = true;
            this.AddListButton.Click += new System.EventHandler(this.AddListButton_Click);
            // 
            // SelectedListLabel
            // 
            this.SelectedListLabel.AutoSize = true;
            this.SelectedListLabel.Location = new System.Drawing.Point(20, 280);
            this.SelectedListLabel.Name = "SelectedListLabel";
            this.SelectedListLabel.Size = new System.Drawing.Size(65, 12);
            this.SelectedListLabel.TabIndex = 1;
            this.SelectedListLabel.Text = "所选的课程";
            // 
            // SelectedListList
            // 
            this.SelectedListList.FormattingEnabled = true;
            this.SelectedListList.ItemHeight = 12;
            this.SelectedListList.Location = new System.Drawing.Point(20, 300);
            this.SelectedListList.Name = "SelectedListList";
            this.SelectedListList.Size = new System.Drawing.Size(120, 112);
            this.SelectedListList.TabIndex = 4;
            // 
            // DeleteSelectedListButton
            // 
            this.DeleteSelectedListButton.Location = new System.Drawing.Point(20, 415);
            this.DeleteSelectedListButton.Name = "DeleteSelectedListButton";
            this.DeleteSelectedListButton.Size = new System.Drawing.Size(120, 23);
            this.DeleteSelectedListButton.TabIndex = 3;
            this.DeleteSelectedListButton.Text = "删除";
            this.DeleteSelectedListButton.UseVisualStyleBackColor = true;
            this.DeleteSelectedListButton.Click += new System.EventHandler(this.DeleteSelectedListButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(160, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "已选课列表ComboBox";
            // 
            // AddedCombo
            // 
            this.AddedCombo.FormattingEnabled = true;
            this.AddedCombo.Location = new System.Drawing.Point(162, 40);
            this.AddedCombo.Name = "AddedCombo";
            this.AddedCombo.Size = new System.Drawing.Size(120, 20);
            this.AddedCombo.TabIndex = 5;
            this.AddedCombo.SelectedIndexChanged += new System.EventHandler(this.AddedComboBox_SelectedIndexChanged);
            // 
            // AddComboLabel
            // 
            this.AddComboLabel.AutoSize = true;
            this.AddComboLabel.Location = new System.Drawing.Point(160, 180);
            this.AddComboLabel.Name = "AddComboLabel";
            this.AddComboLabel.Size = new System.Drawing.Size(71, 12);
            this.AddComboLabel.TabIndex = 1;
            this.AddComboLabel.Text = "添加1门课程";
            // 
            // AddComboText
            // 
            this.AddComboText.Location = new System.Drawing.Point(162, 200);
            this.AddComboText.Name = "AddComboText";
            this.AddComboText.Size = new System.Drawing.Size(120, 21);
            this.AddComboText.TabIndex = 2;
            // 
            // AddComboButton
            // 
            this.AddComboButton.Location = new System.Drawing.Point(162, 225);
            this.AddComboButton.Name = "AddComboButton";
            this.AddComboButton.Size = new System.Drawing.Size(120, 23);
            this.AddComboButton.TabIndex = 3;
            this.AddComboButton.Text = "添加";
            this.AddComboButton.UseVisualStyleBackColor = true;
            this.AddComboButton.Click += new System.EventHandler(this.AddComboButton_Click);
            // 
            // SelectedComboLabel
            // 
            this.SelectedComboLabel.AutoSize = true;
            this.SelectedComboLabel.Location = new System.Drawing.Point(162, 280);
            this.SelectedComboLabel.Name = "SelectedComboLabel";
            this.SelectedComboLabel.Size = new System.Drawing.Size(65, 12);
            this.SelectedComboLabel.TabIndex = 1;
            this.SelectedComboLabel.Text = "所选的课程";
            // 
            // DeletedSelectedComboButton
            // 
            this.DeletedSelectedComboButton.Location = new System.Drawing.Point(162, 415);
            this.DeletedSelectedComboButton.Name = "DeletedSelectedComboButton";
            this.DeletedSelectedComboButton.Size = new System.Drawing.Size(120, 23);
            this.DeletedSelectedComboButton.TabIndex = 3;
            this.DeletedSelectedComboButton.Text = "删除";
            this.DeletedSelectedComboButton.UseVisualStyleBackColor = true;
            this.DeletedSelectedComboButton.Click += new System.EventHandler(this.DeleteSelectedComboButton_Click);
            // 
            // SelectedComboList
            // 
            this.SelectedComboList.FormattingEnabled = true;
            this.SelectedComboList.ItemHeight = 12;
            this.SelectedComboList.Location = new System.Drawing.Point(162, 300);
            this.SelectedComboList.Name = "SelectedComboList";
            this.SelectedComboList.Size = new System.Drawing.Size(120, 112);
            this.SelectedComboList.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 450);
            this.Controls.Add(this.AddedCombo);
            this.Controls.Add(this.SelectedComboList);
            this.Controls.Add(this.DeletedSelectedComboButton);
            this.Controls.Add(this.SelectedListList);
            this.Controls.Add(this.DeleteSelectedListButton);
            this.Controls.Add(this.AddComboButton);
            this.Controls.Add(this.AddListButton);
            this.Controls.Add(this.AddComboText);
            this.Controls.Add(this.SelectedComboLabel);
            this.Controls.Add(this.AddListText);
            this.Controls.Add(this.SelectedListLabel);
            this.Controls.Add(this.AddComboLabel);
            this.Controls.Add(this.AddListLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AddedListLabel);
            this.Controls.Add(this.AddedList);
            this.Name = "Form1";
            this.Text = "选课列表";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox AddedList;
        private System.Windows.Forms.Label AddedListLabel;
        private System.Windows.Forms.Label AddListLabel;
        private System.Windows.Forms.TextBox AddListText;
        private System.Windows.Forms.Button AddListButton;
        private System.Windows.Forms.Label SelectedListLabel;
        private System.Windows.Forms.ListBox SelectedListList;
        private System.Windows.Forms.Button DeleteSelectedListButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox AddedCombo;
        private System.Windows.Forms.Label AddComboLabel;
        private System.Windows.Forms.TextBox AddComboText;
        private System.Windows.Forms.Button AddComboButton;
        private System.Windows.Forms.Label SelectedComboLabel;
        private System.Windows.Forms.Button DeletedSelectedComboButton;
        private System.Windows.Forms.ListBox SelectedComboList;
    }
}

