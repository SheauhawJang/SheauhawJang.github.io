﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week8_C
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void AddedList_Click(object sender, EventArgs e)
        {
            SelectedListList.Items.Clear();
            foreach (string i in AddedList.SelectedItems)
                SelectedListList.Items.Add(i);
        }
        private void AddListButton_Click(object sender, EventArgs e)
        {
            if (AddListText.Text.Length > 0)
                AddedList.Items.Add(AddListText.Text);
            AddListText.Text = "";
        }
        private void DeleteSelectedListButton_Click(object sender, EventArgs e)
        {
            foreach (string x in SelectedListList.Items)
                AddedList.Items.Remove(x);
            SelectedListList.Items.Clear();
        }

        private void AddedComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            SelectedComboList.Items.Clear();
            SelectedComboList.Items.Add(AddedCombo.SelectedItem);
        }
        private void AddComboButton_Click(object sender, EventArgs e)
        {
            if (AddComboText.Text.Length > 0)
                AddedCombo.Items.Add(AddComboText.Text);
            AddComboText.Text = "";
        }
        private void DeleteSelectedComboButton_Click(object sender, EventArgs e)
        {
            foreach (string x in SelectedComboList.Items)
                AddedCombo.Items.Remove(x);
            SelectedComboList.Items.Clear();
        }

    }
}
