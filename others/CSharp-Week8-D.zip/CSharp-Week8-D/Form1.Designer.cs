﻿namespace CSharp_Week8_D
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.UserNameLabel = new System.Windows.Forms.Label();
            this.UserNameText = new System.Windows.Forms.TextBox();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.PasswordComfirmLabel = new System.Windows.Forms.Label();
            this.AgeLabel = new System.Windows.Forms.Label();
            this.AgeUpDown = new System.Windows.Forms.NumericUpDown();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.EmailText = new System.Windows.Forms.TextBox();
            this.GenderGroup = new System.Windows.Forms.GroupBox();
            this.FemaleRadio = new System.Windows.Forms.RadioButton();
            this.MaleRadio = new System.Windows.Forms.RadioButton();
            this.HobbyPenel = new System.Windows.Forms.Panel();
            this.HobbySingCheck = new System.Windows.Forms.CheckBox();
            this.HobbyGameCheck = new System.Windows.Forms.CheckBox();
            this.HobbyReadingCheck = new System.Windows.Forms.CheckBox();
            this.HobbyMusicCheck = new System.Windows.Forms.CheckBox();
            this.HobbyLabel = new System.Windows.Forms.Label();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.PasswordMasked = new System.Windows.Forms.MaskedTextBox();
            this.ComfirmPasswordMasked = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.AgeUpDown)).BeginInit();
            this.GenderGroup.SuspendLayout();
            this.HobbyPenel.SuspendLayout();
            this.SuspendLayout();
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.AutoSize = true;
            this.UserNameLabel.Location = new System.Drawing.Point(32, 24);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.Size = new System.Drawing.Size(41, 12);
            this.UserNameLabel.TabIndex = 0;
            this.UserNameLabel.Text = "用户名";
            // 
            // UserNameText
            // 
            this.UserNameText.Location = new System.Drawing.Point(82, 20);
            this.UserNameText.Name = "UserNameText";
            this.UserNameText.Size = new System.Drawing.Size(100, 21);
            this.UserNameText.TabIndex = 1;
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Location = new System.Drawing.Point(44, 64);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(29, 12);
            this.PasswordLabel.TabIndex = 0;
            this.PasswordLabel.Text = "密码";
            this.PasswordLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // PasswordComfirmLabel
            // 
            this.PasswordComfirmLabel.AutoSize = true;
            this.PasswordComfirmLabel.Location = new System.Drawing.Point(20, 105);
            this.PasswordComfirmLabel.Name = "PasswordComfirmLabel";
            this.PasswordComfirmLabel.Size = new System.Drawing.Size(53, 12);
            this.PasswordComfirmLabel.TabIndex = 0;
            this.PasswordComfirmLabel.Text = "确认密码";
            this.PasswordComfirmLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // AgeLabel
            // 
            this.AgeLabel.AutoSize = true;
            this.AgeLabel.Location = new System.Drawing.Point(244, 24);
            this.AgeLabel.Name = "AgeLabel";
            this.AgeLabel.Size = new System.Drawing.Size(29, 12);
            this.AgeLabel.TabIndex = 0;
            this.AgeLabel.Text = "年龄";
            this.AgeLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // AgeUpDown
            // 
            this.AgeUpDown.Location = new System.Drawing.Point(280, 20);
            this.AgeUpDown.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.AgeUpDown.Name = "AgeUpDown";
            this.AgeUpDown.Size = new System.Drawing.Size(120, 21);
            this.AgeUpDown.TabIndex = 2;
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Location = new System.Drawing.Point(244, 65);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(29, 12);
            this.EmailLabel.TabIndex = 0;
            this.EmailLabel.Text = "邮箱";
            this.EmailLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // EmailText
            // 
            this.EmailText.Location = new System.Drawing.Point(280, 61);
            this.EmailText.Name = "EmailText";
            this.EmailText.Size = new System.Drawing.Size(119, 21);
            this.EmailText.TabIndex = 3;
            // 
            // GenderGroup
            // 
            this.GenderGroup.Controls.Add(this.FemaleRadio);
            this.GenderGroup.Controls.Add(this.MaleRadio);
            this.GenderGroup.Location = new System.Drawing.Point(246, 100);
            this.GenderGroup.Name = "GenderGroup";
            this.GenderGroup.Size = new System.Drawing.Size(153, 47);
            this.GenderGroup.TabIndex = 4;
            this.GenderGroup.TabStop = false;
            this.GenderGroup.Text = "性别";
            // 
            // FemaleRadio
            // 
            this.FemaleRadio.AutoSize = true;
            this.FemaleRadio.Location = new System.Drawing.Point(77, 21);
            this.FemaleRadio.Name = "FemaleRadio";
            this.FemaleRadio.Size = new System.Drawing.Size(35, 16);
            this.FemaleRadio.TabIndex = 1;
            this.FemaleRadio.Text = "女";
            this.FemaleRadio.UseVisualStyleBackColor = true;
            // 
            // MaleRadio
            // 
            this.MaleRadio.AutoSize = true;
            this.MaleRadio.Checked = true;
            this.MaleRadio.Location = new System.Drawing.Point(7, 21);
            this.MaleRadio.Name = "MaleRadio";
            this.MaleRadio.Size = new System.Drawing.Size(35, 16);
            this.MaleRadio.TabIndex = 0;
            this.MaleRadio.TabStop = true;
            this.MaleRadio.Text = "男";
            this.MaleRadio.UseVisualStyleBackColor = true;
            // 
            // HobbyPenel
            // 
            this.HobbyPenel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.HobbyPenel.Controls.Add(this.HobbySingCheck);
            this.HobbyPenel.Controls.Add(this.HobbyGameCheck);
            this.HobbyPenel.Controls.Add(this.HobbyReadingCheck);
            this.HobbyPenel.Controls.Add(this.HobbyMusicCheck);
            this.HobbyPenel.Location = new System.Drawing.Point(20, 160);
            this.HobbyPenel.Name = "HobbyPenel";
            this.HobbyPenel.Size = new System.Drawing.Size(160, 60);
            this.HobbyPenel.TabIndex = 5;
            // 
            // HobbySingCheck
            // 
            this.HobbySingCheck.AutoSize = true;
            this.HobbySingCheck.Location = new System.Drawing.Point(80, 4);
            this.HobbySingCheck.Name = "HobbySingCheck";
            this.HobbySingCheck.Size = new System.Drawing.Size(48, 16);
            this.HobbySingCheck.TabIndex = 1;
            this.HobbySingCheck.Text = "唱歌";
            this.HobbySingCheck.UseVisualStyleBackColor = true;
            // 
            // HobbyGameCheck
            // 
            this.HobbyGameCheck.AutoSize = true;
            this.HobbyGameCheck.Location = new System.Drawing.Point(80, 30);
            this.HobbyGameCheck.Name = "HobbyGameCheck";
            this.HobbyGameCheck.Size = new System.Drawing.Size(48, 16);
            this.HobbyGameCheck.TabIndex = 0;
            this.HobbyGameCheck.Text = "游戏";
            this.HobbyGameCheck.UseVisualStyleBackColor = true;
            // 
            // HobbyReadingCheck
            // 
            this.HobbyReadingCheck.AutoSize = true;
            this.HobbyReadingCheck.Location = new System.Drawing.Point(4, 30);
            this.HobbyReadingCheck.Name = "HobbyReadingCheck";
            this.HobbyReadingCheck.Size = new System.Drawing.Size(48, 16);
            this.HobbyReadingCheck.TabIndex = 0;
            this.HobbyReadingCheck.Text = "看书";
            this.HobbyReadingCheck.UseVisualStyleBackColor = true;
            // 
            // HobbyMusicCheck
            // 
            this.HobbyMusicCheck.AutoSize = true;
            this.HobbyMusicCheck.Location = new System.Drawing.Point(4, 4);
            this.HobbyMusicCheck.Name = "HobbyMusicCheck";
            this.HobbyMusicCheck.Size = new System.Drawing.Size(48, 16);
            this.HobbyMusicCheck.TabIndex = 0;
            this.HobbyMusicCheck.Text = "音乐";
            this.HobbyMusicCheck.UseVisualStyleBackColor = true;
            // 
            // HobbyLabel
            // 
            this.HobbyLabel.AutoSize = true;
            this.HobbyLabel.Location = new System.Drawing.Point(20, 144);
            this.HobbyLabel.Name = "HobbyLabel";
            this.HobbyLabel.Size = new System.Drawing.Size(29, 12);
            this.HobbyLabel.TabIndex = 0;
            this.HobbyLabel.Text = "爱好";
            this.HobbyLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(246, 185);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(154, 23);
            this.SubmitButton.TabIndex = 6;
            this.SubmitButton.Text = "提交";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // PasswordMasked
            // 
            this.PasswordMasked.Location = new System.Drawing.Point(82, 60);
            this.PasswordMasked.Name = "PasswordMasked";
            this.PasswordMasked.PasswordChar = '*';
            this.PasswordMasked.Size = new System.Drawing.Size(100, 21);
            this.PasswordMasked.TabIndex = 7;
            // 
            // ComfirmPasswordMasked
            // 
            this.ComfirmPasswordMasked.Location = new System.Drawing.Point(82, 100);
            this.ComfirmPasswordMasked.Name = "ComfirmPasswordMasked";
            this.ComfirmPasswordMasked.PasswordChar = '*';
            this.ComfirmPasswordMasked.Size = new System.Drawing.Size(100, 21);
            this.ComfirmPasswordMasked.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 234);
            this.Controls.Add(this.ComfirmPasswordMasked);
            this.Controls.Add(this.PasswordMasked);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.HobbyPenel);
            this.Controls.Add(this.GenderGroup);
            this.Controls.Add(this.EmailText);
            this.Controls.Add(this.AgeUpDown);
            this.Controls.Add(this.EmailLabel);
            this.Controls.Add(this.AgeLabel);
            this.Controls.Add(this.HobbyLabel);
            this.Controls.Add(this.PasswordComfirmLabel);
            this.Controls.Add(this.PasswordLabel);
            this.Controls.Add(this.UserNameText);
            this.Controls.Add(this.UserNameLabel);
            this.Name = "Form1";
            this.Text = "用户注册";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.AgeUpDown)).EndInit();
            this.GenderGroup.ResumeLayout(false);
            this.GenderGroup.PerformLayout();
            this.HobbyPenel.ResumeLayout(false);
            this.HobbyPenel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label UserNameLabel;
        private System.Windows.Forms.TextBox UserNameText;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.Label PasswordComfirmLabel;
        private System.Windows.Forms.Label AgeLabel;
        private System.Windows.Forms.NumericUpDown AgeUpDown;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.TextBox EmailText;
        private System.Windows.Forms.GroupBox GenderGroup;
        private System.Windows.Forms.RadioButton FemaleRadio;
        private System.Windows.Forms.RadioButton MaleRadio;
        private System.Windows.Forms.Panel HobbyPenel;
        private System.Windows.Forms.CheckBox HobbySingCheck;
        private System.Windows.Forms.CheckBox HobbyGameCheck;
        private System.Windows.Forms.CheckBox HobbyReadingCheck;
        private System.Windows.Forms.CheckBox HobbyMusicCheck;
        private System.Windows.Forms.Label HobbyLabel;
        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.MaskedTextBox PasswordMasked;
        private System.Windows.Forms.MaskedTextBox ComfirmPasswordMasked;
    }
}

