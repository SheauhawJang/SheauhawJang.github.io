﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week8_D
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (PasswordMasked.Text != ComfirmPasswordMasked.Text)
                    throw new InvaildSubbitInfomationExpection("Password");
                if (!EmailManager.Vaild(EmailText.Text))
                    throw new InvaildSubbitInfomationExpection("Email");
                string info = string.Format(
                    "注册成功!\n用户名为{0}\n年龄为{1}\n邮箱为{2}\n性别为{3}\n爱好为{4}", 
                    UserNameText.Text, AgeUpDown.Value, EmailText.Text,
                    MaleRadio.Checked ? "男" : "女", 
                    string.Join("、", HobbyManager.checkedHobbies));
                MessageBox.Show(info, "注册成功!");
            }
            catch (InvaildSubbitInfomationExpection exp)
            {
                if (exp.Message == "Password")
                    MessageBox.Show("两次密码不一致!", "密码错误");
                else if (exp.Message == "Email")
                    MessageBox.Show("电邮格式不正确！", "电邮错误");
                else
                    MessageBox.Show("未知错误！", "未知错误");
            }
            catch
            {
                MessageBox.Show("未知错误！", "未知错误");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HobbyManager.hobbies = new CheckBox[4];
            HobbyManager.hobbies[0] = HobbyMusicCheck;
            HobbyManager.hobbies[1] = HobbySingCheck;
            HobbyManager.hobbies[2] = HobbyReadingCheck;
            HobbyManager.hobbies[3] = HobbyGameCheck;
        }
    }
    static class HobbyManager
    {
        public static CheckBox[] hobbies;
        public static List<string> checkedHobbies
        {
            get
            {
                List<string> ans = new List<string>();
                foreach (CheckBox hob in hobbies)
                    if (hob.Checked)
                        ans.Add(hob.Text);
                return ans;
            }
        }
    }
    static class EmailManager
    {
        public static bool Vaild(string s)
        {
            foreach (char x in s)
                if (x == '@')
                    return true;
            return false;
        }
    }
    class InvaildSubbitInfomationExpection : ApplicationException
    {
        public InvaildSubbitInfomationExpection(string massage) : base(massage) { }
    }
}
