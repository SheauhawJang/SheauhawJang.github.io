﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week9_B
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_MouseHover(object sender, EventArgs e)
        {
            textBox1.Text = "悬停中";
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            Panel panel1 = (Panel)sender;
            if (e.Button == MouseButtons.Left)
                textBox1.Text = string.Format("左键单击\n({0},{1})", panel1.Location.X, panel1.Location.Y);
            else
                textBox1.Text = "右键单击";
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.ControlKey:
                case Keys.Menu:
                case Keys.ShiftKey:
                    textBox1.Text = Convert.ToString(e.KeyCode);
                    break;
            }
            if (e.KeyCode >= Keys.A && e.KeyCode <= Keys.Z)
                textBox1.Text = Convert.ToString(e.KeyCode);
        }
    }
}
