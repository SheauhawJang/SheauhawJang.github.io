﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week9_C
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Manager.rtexts = new TextBox[6]
                { textBox1, textBox2, textBox3, textBox4, textBox5, textBox6 };
            Manager.btext = textBox12;
            Manager.vs = new int[Manager.rsz];
            for (int i = 0; i < Manager.vs.Length; ++i)
                Manager.vs[i] = i + 1;
            Manager.tool = new Random();
            Manager.Hajime = false;
            Manager.Update();
            timer1.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Manager.Hajime = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Manager.Hajime = false;
            List<string> vs = new List<string>();
            foreach (TextBox text in Manager.rtexts)
                vs.Add(text.Text);
            MessageBox.Show(
                string.Format("本期福利彩票的中奖号码是\n红球:{0}\n蓝球:{1}", 
                    string.Join(",", vs), Manager.btext.Text), 
                "开奖啦!");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Manager.Hajime)
                Manager.Update();
        }
    }
    public static class Manager
    {
        public static TextBox[] rtexts;
        public static TextBox btext;
        public const int rsz = 33;
        public const int bsz = 16;
        public static int[] vs;
        public static void Swap<T>(ref T a, ref T b)
        {
            T tmp = b;
            b = a;
            a = tmp;
        }
        public static void Shuffle()
        {
            for (int i = 0; i < vs.Length; ++i)
                Swap(ref vs[i], ref vs[tool.Next(i, vs.Length)]);
        }
        public static void Update()
        {
            Shuffle();
            for (int i = 0; i < rtexts.Length; ++i)
                rtexts[i].Text = string.Format("{0:00}", vs[i]);
            btext.Text = string.Format("{0:00}", tool.Next(1, bsz + 1));
        }
        public static Random tool;
        public static bool Hajime { get; set; }
    }
}
