﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Week9_D
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            SolidBrush bush = new SolidBrush(Color.Black);
            Pen pen = new Pen(bush);
            Graphics g = e.Graphics;
            g.DrawEllipse(pen, 150, 50, 50, 50);
            g.FillRectangle(bush, 125, 100, 100, 100);
            g.DrawLine(pen, 150, 200, 130, 300); // tuizi 1
            g.DrawLine(pen, 200, 200, 220, 300); // tuizi 2
            g.DrawLine(pen, 125, 120, 75, 180); // gebei 1
            g.DrawLine(pen, 225, 120, 275, 180); // gebei 2
            /*
            GraphicsPath path = new GraphicsPath();
            Font font = new Font("黑体", 72);
            Point pt = new Point(300, 100);
            string s = "张晓昊 数试92";
            path.AddString(s, font.FontFamily, (int)font.Style, font.SizeInPoints, pt, StringFormat.GenericTypographic);
            g.DrawPath(pen, path);
            Point ptr = pt;
            ptr.Offset(2, 2);
            GraphicsPath rPath = new GraphicsPath();
            Brush shadow = new SolidBrush(Color.FromArgb(100, 0, 0, 0));
            rPath.AddString(s, font.FontFamily, (int)font.Style, font.SizeInPoints, ptr, StringFormat.GenericTypographic);
            g.FillPath(shadow, rPath);
            g.DrawPath(pen, rPath);
            shadow.Dispose();
            */
        }
    }
}
